/**
 * 
 */
package org.arch.dns.exception;

/**
 * @author wqy
 *
 */
public class ServiceUnavailableException extends NamingException
{

	public ServiceUnavailableException(String msg)
    {
	    super(msg);
    }
	
}
