/**
 * 
 */
package org.arch.dns.exception;

/**
 * @author yinqiwen
 *
 */
public class OperationNotSupportedException extends NamingException
{

	public OperationNotSupportedException(String msg)
    {
	    super(msg);
    }
	
}
