/**
 * 
 */
package org.arch.dns.exception;

/**
 * @author yinqiwen
 *
 */
public class NameNotFoundException extends NamingException
{

	public NameNotFoundException(String msg)
    {
	   super(msg);
    }
	
}
