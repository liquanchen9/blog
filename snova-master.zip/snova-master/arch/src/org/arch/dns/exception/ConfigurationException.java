/**
 * 
 */
package org.arch.dns.exception;

/**
 * @author yinqiwen
 *
 */
public class ConfigurationException extends NamingException
{

	public ConfigurationException()
    {

    }
	public ConfigurationException(String msg)
    {
	    super(msg);
    }
	
}
