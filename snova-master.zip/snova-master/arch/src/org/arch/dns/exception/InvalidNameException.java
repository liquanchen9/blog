/**
 * 
 */
package org.arch.dns.exception;

/**
 * @author yinqiwen
 *
 */
public class InvalidNameException extends NamingException
{

	public InvalidNameException(String msg)
    {
	    super(msg);
    }
	
}
