/**
 * 
 */
package org.arch.dns.exception;

/**
 * @author yinqiwen
 *
 */
public class CommunicationException extends NamingException
{

	public CommunicationException(String msg)
    {
	    super(msg);
    }
	
}
