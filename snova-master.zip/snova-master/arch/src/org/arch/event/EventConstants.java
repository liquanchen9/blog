/**
 * 
 */
package org.arch.event;

/**
 * @author wqy
 *
 */
public interface EventConstants
{
	public static final int COMPRESS_EVENT_TYPE = 1500;
	public static final int ENCRYPT_EVENT_TYPE = 1501;
}
