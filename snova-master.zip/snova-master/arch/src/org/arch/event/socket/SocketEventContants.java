/**
 * 
 */
package org.arch.event.socket;

/**
 * @author qiyingwang
 *
 */
public interface SocketEventContants
{
	public static final int SOCKET_CONNECT_EVENT_TYPE = 900;
	public static final int SOCKET_CHUNK_EVENT_TYPE = 901;
	public static final int SOCKET_CLOSE_EVENT_TYPE = 902;
}
