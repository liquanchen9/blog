/**
 * 
 */
package org.arch.event;

/**
 * @author qiyingwang
 *
 */
public interface NamedEventHandler extends EventHandler
{
	public String getName();
}
