/**
 * 
 */
package org.snova.framework.proxy.common;

/**
 * @author qiyingwang
 *
 */
public enum RangeFetchStatus
{
	WAITING_NORMAL_RESPONSE,WAITING_MULTI_RANGE_RESPONSE,WATING_RANGE_UPLOAD_RESPONSE
}
