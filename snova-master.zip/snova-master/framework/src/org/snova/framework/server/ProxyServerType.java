/**
 * 
 */
package org.snova.framework.server;

/**
 * @author yinqiwen
 * 
 */
public enum ProxyServerType
{
	AUTO, GAE, C4
}
